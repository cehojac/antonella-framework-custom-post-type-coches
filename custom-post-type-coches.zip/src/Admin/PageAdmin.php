<?php

namespace CPTC\Admin;

class PageAdmin extends Admin
{
    function index()
    {

    }

}
