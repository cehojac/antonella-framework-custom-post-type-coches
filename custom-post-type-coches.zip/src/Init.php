<?php
namespace CPTC;

class Init
{
    public function __construct()
    {

    }

    public function index()
    {

    }
}
