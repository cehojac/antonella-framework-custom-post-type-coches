<?php
namespace CPTC;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
